<?php

/* +***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * *********************************************************************************** */

class Settings_ColorizerApp_RelatedModulelist_View extends Settings_Vtiger_Index_View {

	public function process(Vtiger_Request $request) {
		$moduleName = $request->getModule();
		$qualifiedModuleName = $request->getModule(false);
		$sourceModID = $request->get('sourceMod');
		$contacModuleModel = Vtiger_Module_Model::getInstance(vtlib_getModuleNameById($sourceModID));
        $relationModules = Vtiger_Relation_Model::getAllRelations($contacModuleModel);
        foreach ($relationModules as $relationModuleModel) {
            $relatedModuleName[$relationModuleModel->get('related_tabid')] = $relationModuleModel->get('relatedModuleName');
        }

        $response = new Vtiger_Response();
        $response->setResult(array('success'=>'true','relatedlist'=>$relatedModuleName));
        $response->emit();
	}
}
