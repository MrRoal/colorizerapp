<?php

/* +***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * *********************************************************************************** */

class Settings_ColorizerApp_Widget_View extends Settings_Vtiger_Index_View {

	public function process(Vtiger_Request $request) {
		$moduleName = $request->getModule();
		$qualifiedModuleName = $request->getModule(false);
		$viewer = $this->getViewer($request);

		//$tabId = $request->get('tabId');
		$tabId = 7;
        $qualifiedModuleName = $request->getModule(false);
        $viewer = $this->getViewer($request);
        $viewer->assign('SELECTED_MODULE', vtlib_getModuleNameById($tabId));
        if($type == 'Comments'){
            $viewer->view('Comments.tpl', $qualifiedModuleName);
        }else{
            $contacModuleModel = Vtiger_Module_Model::getInstance(vtlib_getModuleNameById($tabId));
            $relationModules = Vtiger_Relation_Model::getAllRelations($contacModuleModel);
            foreach ($relationModules as $relationModuleModel) {
                $relatedModuleName[$relationModuleModel->get('related_tabid')] = $relationModuleModel->get('relatedModuleName');
            }
            $isactionselect = 0;
            $isactionadd = 0;
            $viewer->assign('ALL_MODULES', Settings_Workflows_Module_Model::getSupportedModules());
            $viewer->assign('ISACTIONSELECT',$isactionselect);
            $viewer->assign('ISACTIONADD',$isactionadd);
            $viewer->assign('RELATEDMODULES',$relatedModuleName);
            
        }
		
		$viewer->view('Widget.tpl', $qualifiedModuleName);
	}
}
