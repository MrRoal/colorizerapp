<?php

/* +***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * *********************************************************************************** */
Class Settings_ColorizerApp_Edit_View extends Settings_Vtiger_Index_View {

     public function process(Vtiger_Request $request) {
        global $adb;
        $currentUser = Users_Record_Model::getCurrentUserModel();
        $viewer = $this->getViewer($request);
        $qualifiedModuleName = $request->getModule(false);
        $allModules = Settings_Workflows_Module_Model::getSupportedModules();

        $recordId = $request->get('record');
        if ($recordId) {
            $getquery = "SELECT * FROM vtiger_colorizerconfig WHERE deleted = 0 AND colorizerid = ?";
            $Result = $adb->pquery($getquery, array($recordId));
            $num_rows = $adb->num_rows($Result);

            /*$getCondquery = "SELECT * FROM vtiger_colorizercondition WHERE colorizerid = ?";
            $condResult = $adb->pquery($getCondquery, array($recordId));
            $condnum_rows = $adb->num_rows($condResult);*/

            $RecordModels = array();
            while($Result && $row=$adb->fetch_row($Result)) {
                $RecordModels['colorizerid'] = $row['colorizerid'];
                $RecordModels['filtername'] = $row['filtername'];
                $RecordModels['status'] = $row['status'];
                $RecordModels['sourcemodule'] = vtlib_getModuleNameById($row['sourcemodule']);
                $RecordModels['relatedmodule'] = vtlib_getModuleNameById($row['relatedmodule']);
                $RecordModels['userid'] = $row['userid'];
                $RecordModels['textcolor'] = $row['textcolor'];
                $RecordModels['bgcolor'] = $row['bgcolor'];
            }

            /*$condition = array();
            $i = 0;
            while($condResult && $condrow=$adb->fetch_row($condResult)) {
                $condition[$i]['columnname'] = $condrow['columnname'];
                $condition[$i]['comparator'] = $condrow['comparator'];
                $condition[$i]['columnvalue'] = $condrow['columnvalue'];
                $condition[$i]['type'] = $condrow['type'];
                $i++;
            }*/
            /*echo "<pre>";print_r($condition);exit;*/
            $viewer->assign('RECORDID', $recordId);
            $viewer->assign('SELECTED_MODULE', $RecordModels['sourcemodule']);
            $viewer->assign('RELATEDMODULE', $RecordModels['relatedmodule']);
            $viewer->assign('RECORDMODELS', $RecordModels);
        }

        
        $viewer->assign('MODULE_MODEL', $selectedModule);
        $viewer->assign('SELECTED_MODULE_NAME', $selectedModuleName);

        $dateFilters = Vtiger_Field_Model::getDateFilterTypes();
        foreach($dateFilters as $comparatorKey => $comparatorInfo) {
            $comparatorInfo['startdate'] = DateTimeField::convertToUserFormat($comparatorInfo['startdate']);
            $comparatorInfo['enddate'] = DateTimeField::convertToUserFormat($comparatorInfo['enddate']);
            $comparatorInfo['label'] = vtranslate($comparatorInfo['label'], $qualifiedModuleName);
            $dateFilters[$comparatorKey] = $comparatorInfo;
        }
        $viewer->assign('DATE_FILTERS', $dateFilters);
        $viewer->assign('ALL_MODULES', $allModules);
        $viewer->assign('MODULE', $moduleName);
        $viewer->assign('ISACTIONSELECT',$isactionselect);
        $viewer->assign('ISACTIONADD',$isactionadd);
        $viewer->assign('QUALIFIED_MODULE', $qualifiedModuleName);
        $viewer->assign('CURRENT_USER', $currentUser);
        $viewer->assign('ADVANCED_FILTER_OPTIONS', Settings_ColorizerApp_Field_Model::getAdvancedFilterOptions());
        $viewer->assign('ADVANCED_FILTER_OPTIONS_BY_TYPE', Settings_ColorizerApp_Field_Model::getAdvancedFilterOpsByFieldType());
        $admin = Users::getActiveAdminUser();
        $viewer->view('EditView.tpl', $qualifiedModuleName);
    }

    public function getHeaderScripts(Vtiger_Request $request) {
        $headerScriptInstances = parent::getHeaderScripts($request);
        $moduleName = $request->getModule();

        $jsFileNames = array(
            'modules.Settings.Vtiger.resources.Edit',
            'modules.Settings.ColorizerApp.resources.Edit',
            "modules.Settings.ColorizerApp.resources.libraries.jscolor.jscolor",
        );

        $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
        $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
        return $headerScriptInstances;
    }

    function getHeaderCss(Vtiger_Request $request) {
        $headerCssInstances = parent::getHeaderCss($request);
        $moduleName = $request->getModule();
        $cssFileNames = array(
            '~libraries/jquery/jquery.datepick.package-4.1.0/jquery.datepick.css',
            '~/libraries/jquery/bootstrapswitch/css/bootstrap3/bootstrap-switch.min.css',
        );
        $cssInstances = $this->checkAndConvertCssStyles($cssFileNames);
        $headerCssInstances = array_merge($cssInstances, $headerCssInstances);
        return $headerCssInstances;
    }
    
}
