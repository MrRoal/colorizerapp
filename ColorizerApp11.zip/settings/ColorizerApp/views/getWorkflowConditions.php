<?php

/* +***********************************************************************************
 * The contents of this file are subject to the CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  CRM Open Source
 * The Initial Developer of the Original Code.
 * Portions created by .
 * All Rights Reserved.
 * *********************************************************************************** */

class Settings_ColorizerApp_getWorkflowConditions_View extends Settings_Vtiger_Index_View {

	public function process(Vtiger_Request $request) {
    global $adb;
        $moduleid = $request->get('module_name');
        $recordId = $request->get('record');
        $moduleName = vtlib_getModuleNameById($moduleid);
        $viewer = $this->getViewer($request);
        $qualifiedModuleName = $request->getModule(false);

       $moduleModel = Vtiger_Module_Model::getInstance($moduleName);
       $allFields = $moduleModel->getFields();

       $Moduleallfields = array();
       foreach($allFields as $index=>$fields) {
           $block = $fields->get('block');
           $Moduleallfields[$block->label][$fields->get('column')] = $fields->get('label');
       }
       if ($recordId) {
            $getquery = "SELECT * FROM vtiger_colorizerconfig WHERE deleted = 0 AND colorizerid = ?";
            $Result = $adb->pquery($getquery, array($recordId));
            $num_rows = $adb->num_rows($Result);

            $getAllCondquery = "SELECT * FROM vtiger_colorizercondition WHERE colorizerid = ? AND type = 'and'";
            $allCondResult = $adb->pquery($getAllCondquery, array($recordId));
            $allCondnum_rows = $adb->num_rows($allCondResult);

            $getAnyCondquery = "SELECT * FROM vtiger_colorizercondition WHERE colorizerid = ? AND type = 'or'";
            $anyCondResult = $adb->pquery($getAnyCondquery, array($recordId));
            $anyCondnum_rows = $adb->num_rows($anyCondResult);

            $RecordModels = array();
            while($Result && $row=$adb->fetch_row($Result)) {
                $RecordModels['colorizerid'] = $row['colorizerid'];
                $RecordModels['filtername'] = $row['filtername'];
                $RecordModels['status'] = $row['status'];
                $RecordModels['sourcemodule'] = vtlib_getModuleNameById($row['sourcemodule']);
                $RecordModels['relatedmodule'] = vtlib_getModuleNameById($row['relatedmodule']);
                $RecordModels['userid'] = $row['userid'];
                $RecordModels['textcolor'] = $row['textcolor'];
                $RecordModels['bgcolor'] = $row['bgcolor'];
            }

            $allCondition = array();
            $i = 0;
            while($allCondnum_rows && $allCondCow=$adb->fetch_row($allCondResult)) {
                $allCondition[$i]['columnname'] = $allCondCow['columnname'];
                $allCondition[$i]['comparator'] = $allCondCow['comparator'];
                $allCondition[$i]['columnvalue'] = $allCondCow['columnvalue'];
                $allCondition[$i]['type'] = $allCondCow['type'];
                $i++;
            }
            $anyCondition = array();
            $j = 0;
            while($anyCondnum_rows && $anyCondCow=$adb->fetch_row($anyCondResult)) {
                $anyCondition[$j]['columnname'] = $anyCondCow['columnname'];
                $anyCondition[$j]['comparator'] = $anyCondCow['comparator'];
                $anyCondition[$j]['columnvalue'] = $anyCondCow['columnvalue'];
                $anyCondition[$j]['type'] = $anyCondCow['type'];
                $j++;
            }
           
            $viewer->assign('RECORDID', $recordId);
            $viewer->assign('ALL_CONDITION_CRITERIA', $allCondition);
            $viewer->assign('ANY_CONDITION_CRITERIA', $anyCondition);
            $viewer->assign('SELECTED_MODULE', $RecordModels['sourcemodule']);
            $viewer->assign('RELATEDMODULE', $RecordModels['relatedmodule']);
            $viewer->assign('RECORDMODELS', $RecordModels);
        }
       $viewer->assign('MODULEALLFIELDS',$Moduleallfields);
        $viewer->assign('QUALIFIED_MODULE', $qualifiedModuleName);
        $viewer->view('getWorkflowConditions.tpl', $qualifiedModuleName);
    }
}
