<?php

/* +***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * *********************************************************************************** */

class Settings_ColorizerApp_Config_View extends Settings_Vtiger_Index_View {

	public function process(Vtiger_Request $request) {
		global $adb;
		$moduleName = $request->getModule();
		$qualifiedModuleName = $request->getModule(false);
		$viewer = $this->getViewer($request);
		$listquery = "SELECT * FROM vtiger_colorizerconfig WHERE deleted = 0";
		$listResult = $adb->pquery($listquery, array());
		$num_rows = $adb->num_rows($listResult);

		$listViewRecordModels = array();
		while($listResult && $row=$adb->fetch_row($listResult)) {
			$listViewRecordModels[$row['colorizerid']]['colorizerid'] = $row['colorizerid'];
			$listViewRecordModels[$row['colorizerid']]['filtername'] = $row['filtername'];
			$listViewRecordModels[$row['colorizerid']]['status'] = $row['status'];
			$listViewRecordModels[$row['colorizerid']]['sourcemodule'] = vtlib_getModuleNameById($row['sourcemodule']);
			$listViewRecordModels[$row['colorizerid']]['relatedmodule'] = vtlib_getModuleNameById($row['relatedmodule']);
			$listViewRecordModels[$row['colorizerid']]['userid'] = $row['userid'];
			$listViewRecordModels[$row['colorizerid']]['textcolor'] = $row['textcolor'];
			$listViewRecordModels[$row['colorizerid']]['bgcolor'] = $row['bgcolor'];
		}
		
		$viewer->assign('LISTVIEW_ENTRIES', $listViewRecordModels);
		$viewer->view('Index.tpl', $qualifiedModuleName);
	}

	/**
	 * Function to get the list of Script models to be included
	 * @param Vtiger_Request $request
	 * @return <Array> - List of Vtiger_JsScript_Model instances
	 */
	function getHeaderScripts(Vtiger_Request $request) {
		$headerScriptInstances = parent::getHeaderScripts($request);
		$moduleName = $request->getModule();

		$jsFileNames = array(
			"modules.Settings.$moduleName.resources.Index.js"
		);

		$jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
		$headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
		return $headerScriptInstances;
	}

}
