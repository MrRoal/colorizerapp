<?php
/*+**********************************************************************************
 * The contents of this file are subject to the Version 1.1
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code By:  Rahul
 * The Initial Developer of the Original Code By Rahul.
 * Portions created by Rahul.
 * All Rights Reserved.
 ************************************************************************************/
class Settings_ColorizerApp_SaveColorizer_Action extends Settings_Vtiger_Basic_Action {

	public function process(Vtiger_Request $request) {
		global $adb, $current_user;
		$qualifiedModuleName = $request->getModule(false);
		$moduleName = $request->get('module');
		$recordId = $request->get('record');
		$conditionname = $request->get('conditionname');
		$moduleslist = $request->get('moduleslist');
		$relatedmodule = $request->get('relatedmodule');
		$textcolor = $request->get('textcolor');
		$bgcolor = $request->get('bgcolor');
		$status = $request->get('status');
		$userid = $current_user->id;
		$columnname = $_REQUEST['columnname'];
		array_pop($columnname);
		$comparator = $_REQUEST['comparator'];
		array_pop($comparator);
		$columnvalue = $_REQUEST['columnvalue'];
		array_pop($columnvalue);
		
		$anycolumnname = $_REQUEST['anycolumnname'];
		array_pop($anycolumnname);
		$anycomparator = $_REQUEST['anycomparator'];
		array_pop($anycomparator);
		$anycolumnvalue = $_REQUEST['anycolumnvalue'];
		array_pop($anycolumnvalue);
		if(empty($recordId)) {
			$sql = "INSERT INTO vtiger_colorizerconfig(filtername, status, sourcemodule, relatedmodule, userid, textcolor, bgcolor) VALUES (?,?,?,?,?,?,?)";
			$params = array($conditionname,$status,$moduleslist,$relatedmodule,$userid,$textcolor,$bgcolor);
		} else {
			$sql = "UPDATE vtiger_colorizerconfig SET filtername=?, status=?, sourcemodule=?, relatedmodule=?, userid=?, textcolor=?, bgcolor=? WHERE colorizerid = ?";
			$params = array($conditionname,$status,$moduleslist,$relatedmodule,$userid,$textcolor,$bgcolor,$recordId);
		}
		$response = new Vtiger_Response();
		try {
			$adb->pquery($sql,$params);
			if (empty($recordId)) {
				$lastinsertedid = $adb->getLastInsertID();
			}else{
				$delConsql = "DELETE FROM vtiger_colorizercondition where colorizerid = ?";
				$delparams = array($recordId);
				$adb->pquery($delConsql,$delparams);
				$lastinsertedid = $recordId;
			}
			foreach ($columnname as $key => $value) {
				$fieldName = $columnname[$key];
				$condition = $comparator[$key];
				$fieldValue = $columnvalue[$key];
				$allconsql = "INSERT INTO vtiger_colorizercondition(colorizerid , columnname, comparator, columnvalue, type) VALUES (?,?,?,?,?)";
				$allparams = array($lastinsertedid,$fieldName,$condition,$fieldValue,'and');
				$adb->pquery($allconsql,$allparams);
			}
			foreach ($anycolumnname as $key => $value) {
				$fieldName = $anycolumnname[$key];
				$condition = $anycomparator[$key];
				$fieldValue = $anycolumnvalue[$key];
				$anyconsql = "INSERT INTO vtiger_colorizercondition(colorizerid , columnname, comparator, columnvalue, type) VALUES (?,?,?,?,?)";
				$anyparams = array($lastinsertedid,$fieldName,$condition,$fieldValue,'or');
				$adb->pquery($anyconsql,$anyparams);
			}
			$response->setResult(array('success' => true));
		} catch (Exception $ex) {
			$response->setResult(array('success' => false));
		}
		$loadUrl = 'index.php?module=ColorizerApp&parent=Settings&view=Config&block=4&fieldid=41';
		header("Location: $loadUrl");
	}
}
