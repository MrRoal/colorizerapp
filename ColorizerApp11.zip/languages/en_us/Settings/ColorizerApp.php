<?php

/**
 * Author : Nilay Khatri
 * Company : Automate SMB Enterprises, India
 * Email : nilay@automatesmb.com
 */
$languageStrings = array(
    'send_mail' => 'Send mail',
    'send_sms' => 'Send SMS',
    'Sent Email When Mention In Comment' => 'Configure Notifications',
    'show_notification' => 'Show Notification'
);
