<?php

class ColorizerApp {

    public function vtlib_handler($moduleName, $eventType) {
        if ($eventType == 'module.postinstall') {
            $this->_registerSettingsLink($moduleName);
        } else if ($eventType == 'module.enabled') {
            
        } else if ($eventType == 'module.disabled') {
        }
    }

    /**
     * add settings link
     * @param type $moduleName
     */
    protected function _registerSettingsLink($moduleName) {
        $adb = PearDatabase::getInstance();

        $fieldid = $adb->getUniqueID('vtiger_settings_field');
        $blockid = getSettingsBlockId('LBL_OTHER_SETTINGS');
        $seq_res = $adb->pquery("SELECT max(sequence) AS max_seq FROM vtiger_settings_field WHERE blockid = ?", array($blockid));
        if ($adb->num_rows($seq_res) > 0) {
            $cur_seq = $adb->query_result($seq_res, 0, 'max_seq');
            if ($cur_seq != null)
                $seq = $cur_seq + 1;
        }

        $result = $adb->pquery('SELECT 1 FROM vtiger_settings_field WHERE name=?', array($moduleName));
        if (!$adb->num_rows($result)) {
            $adb->pquery('INSERT INTO vtiger_settings_field(fieldid, blockid, name, iconpath, description, linkto, sequence)
                                            VALUES (?,?,?,?,?,?,?)', array($fieldid, $blockid, 'ColorizerApp', '', 'Colorizer App Settings', 'index.php?module=ColorizerApp&parent=Settings&view=Config', $seq));
        }
    }

}


