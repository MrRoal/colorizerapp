<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/

class ColorizerApp_RelatedColor_Action extends Vtiger_Action_Controller {

	function checkPermission(Vtiger_Request $request) {
		return;
	}

	public function process(Vtiger_Request $request) {
		global $adb;
		$records = $request->get('records');
		$sourceModule = $request->get('sourceModule');
		$sourceModuleId = getTabid($request->get('sourceModule'));
		$getquery = "SELECT * FROM vtiger_colorizerconfig
			INNER JOIN vtiger_colorizercondition ON vtiger_colorizercondition.colorizerid = vtiger_colorizerconfig.colorizerid
			WHERE vtiger_colorizerconfig.status = ? AND vtiger_colorizerconfig.sourcemodule = ? ORDER BY vtiger_colorizerconfig.colorizerid , vtiger_colorizercondition.type ASC";
		$getval = $adb->pquery($getquery,array('active',$sourceModuleId));
		$num_rows = $adb->num_rows($getval);
		$conditionarr = array();
		for ($i=0; $i < $num_rows; $i++) { 
			$colorizerid  = $adb->query_result($getval, $i, 'colorizerid');
			$type        = $adb->query_result($getval, $i, 'type');
			$conditionarr[$colorizerid][$type][$i]['columnname']  = $adb->query_result($getval, $i, 'columnname');
			$conditionarr[$colorizerid][$type][$i]['comparator']  = $adb->query_result($getval, $i, 'comparator');
			$conditionarr[$colorizerid][$type][$i]['columnvalue'] = $adb->query_result($getval, $i, 'columnvalue');
			$conditionarr[$colorizerid][$type][$i]['textcolor']        = $adb->query_result($getval, $i, 'textcolor');
			$conditionarr[$colorizerid][$type][$i]['bgcolor']        = $adb->query_result($getval, $i, 'bgcolor');
		}



		$recordswithcolor = array();
		$query = getListQuery($sourceModule);
		
		foreach ($records as $key1 => $record) {
			$objMO = CRMEntity::getInstance($sourceModule);
            $objMO->retrieve_entity_info($record, $sourceModule);
            $conditionstring = "";
            

            foreach ($conditionarr as $key2 => $conditions) {
            	foreach ($conditions as $key => $condition) {
            		foreach ($condition as $value) {
            			$columnname = $value['columnname'];
						$getTab = "SELECT tablename FROM vtiger_field WHERE tabid =? AND columnname = ?";
						$gettable = $adb->pquery($getTab,array($sourceModuleId,$columnname));
						$tablename = $adb->query_result($gettable, 0, 'tablename');
						$columnname = $tablename.'.'.$columnname;
		            	$comparator = $value['comparator'];
		            	$columnvalue = $value['columnvalue'];
		            	$textcolor = $value['textcolor'];
		            	$bgcolor = $value['bgcolor'];
	            		$recordvalue = $objMO->column_fields[$columnname];

	            		if($key == 'and'){
	            			if($comparator == 'IS'){
				            	$string =  ' '.$columnname .' = "'.$columnvalue .'" ';
			            	}elseif($comparator == 'IS_NOT'){
			            		$string =  ' '.$columnname .' != "'.$columnvalue .'" ';
			            	}elseif($comparator == 'COTAINS'){
			            		$string =  ' '.$columnname .' LIKE "'.$columnvalue .'" ';
			            	}elseif($comparator == 'DOES_NOT_CONTAINS'){
			            		$string =  ' '.$columnname .'NOT LIKE "'.$columnvalue .'" ';
			            	}elseif($comparator == 'IS_EMPTY'){
			            		$string =  ' '.$columnname .' = "" ';
			            	}elseif($comparator == 'IS_NOT_EMPTY'){
			            		$string =  ' '.$columnname .' != "" ';
			            	}
			            	if(strpos($conditionstring,$string) === false){
                                    $conditionstring .= ' AND ('.$string.' ) ';
                              }
			            	
	            		}elseif($key == 'or'){
	            			if($comparator == 'IS'){
				            	$string =  ' '.$columnname .' = "'.$columnvalue .'" ';
			            	}elseif($comparator == 'IS_NOT'){
			            		$string =  ' '.$columnname .' != "'.$columnvalue .'" ';
			            	}elseif($comparator == 'COTAINS'){
			            		$string =  ' '.$columnname .' LIKE "'.$columnvalue .'" ';
			            	}elseif($comparator == 'DOES_NOT_CONTAINS'){
			            		$string =  ' '.$columnname .'NOT LIKE "'.$columnvalue .'" ';
			            	}elseif($comparator == 'IS_EMPTY'){
			            		$string =  ' '.$columnname .' = "" ';
			            	}elseif($comparator == 'IS_NOT_EMPTY'){
			            		$string =  ' '.$columnname .' != "" ';
			            	}
			            	if(strpos($conditionstring,$string) === false){
	                            $conditionstring .= ' OR ('.$string.' ) ';
	                        }
			            	
	            		}
            		}
            		$conditionstring = ' ('.$conditionstring.' )';
            	}

            	$conditionstring = ' AND ('.$conditionstring.' )';
            	$conditionstring =  str_replace('( AND','',$conditionstring);
            	$conditionstring = rtrim($conditionstring,")");
            	
            	$listQuery = $query." AND vtiger_crmentity.crmid = $record ".$conditionstring;
            	$conditionstring = '';
            	$listQueryres = $adb->pquery($listQuery,array());
				$reccount = $adb->num_rows($listQueryres);
				if($reccount > 0){
					$recordswithcolor[] = array("record"=>$record,"text_color"=>$textcolor,"bg_color"=>$bgcolor);
				}
            }
		}


		$response = new Vtiger_Response();
		$response->setResult($recordswithcolor);
		$response->emit();
	}
}
