
var Vtiger_RelatedListviewColorsVTE_Js = {
    listViewContainer: null,
    records: null,

    init: function () {
        if (this.validRelatedListViewData()) {
            var thisInstance = this;
            var aDeferred = jQuery.Deferred();
            var viewName = app.getViewName();
            var records = [];
            var urlParams = {};
            jQuery('tr.listViewEntries', this.listViewContainer).each(function () {
                records.push(jQuery(this).data('id'));
            });
            if(viewName == 'List') {
                urlParams['sourceModule'] = app.getModuleName();
            }
            if(viewName == 'Detail') {
                urlParams['sourceModule'] = jQuery('input[name=relatedModuleName]').val();
            }
            urlParams['module'] = 'ColorizerApp';
            urlParams['action'] = 'RelatedColor';
            urlParams['records'] = records;
            AppConnector.request(urlParams).then(
                function (data) {
                    var response = data;
                    if (response.success) {
                        if (response.result) {
                            thisInstance.records = response.result;
                            thisInstance.setColorRows();
                        }
                    }
                    aDeferred.resolve(data);
                },

                function (error) {
                    aDeferred.reject(error);
                }
            );

            return aDeferred.promise();
        }
    },

    validRelatedListViewData: function () {
        var viewName = app.getViewName();
        if(viewName == 'List') {
            if(jQuery('#listview-table tr.listViewEntries').length > 0) {
                this.listViewContainer = jQuery('#listview-table');
                return true;
            }
        }

        if (viewName == 'Detail') {
            if (jQuery('.detailview-content .relatedContents #listview-table tr.listViewEntries').length > 0) {
                this.listViewContainer = jQuery('.detailview-content .relatedContents');
                return true;
            }
        }
        return false;
    },

    setColorRows: function () {
        if (this.records.length > 0) {
            for (var i in this.records) {
                jQuery('#listview-table').find('tr[data-id=' + this.records[i].record + ']').css('background-color', this.records[i].bg_color);
                jQuery('#listview-table').find('tr[data-id=' + this.records[i].record + ']').css('color', this.records[i].text_color );
                jQuery('#listview-table').find('tr[data-id=' + this.records[i].record + '] a').attr('style', 'color: '+this.records[i].text_color +' !important;');
                jQuery('#listview-table').find('tr[data-id=' + this.records[i].record + '] span .value').css('color', this.records[i].text_color );
            }
        }
    }
}

jQuery(document).ready(function () {
    Vtiger_RelatedListviewColorsVTE_Js.init();
});
jQuery(document).on('pjax:complete', function(event) {
  Vtiger_RelatedListviewColorsVTE_Js.init();
});