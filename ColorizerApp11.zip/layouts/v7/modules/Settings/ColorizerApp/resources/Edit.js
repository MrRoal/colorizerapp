/* ********************************************************************************
 * The content of this file is subject to the ("License");
 * You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is
 * Portions created by.
 * All Rights Reserved.
 * ****************************************************************************** */

jQuery.Class("ColorizerApp_Edit_Js",{
    editInstance:false,
    getInstance: function(){
        if(BoruSummaryWidgets_Settings_Js.editInstance == false){
            var instance = new BoruSummaryWidgets_Settings_Js();
            BoruSummaryWidgets_Settings_Js.editInstance = instance;
            return instance;
        }
        return BoruSummaryWidgets_Settings_Js.editInstance;
    }
},{
    advanceFilterInstance: false,
    changeSourceModule:function(){
        var thisInstance=this;
        $("select[name='relatedmodule']").val();
        jQuery("select[name='moduleslist']").change(function (e) {
            var thisInstance = this;
            app.helper.showProgress();
            var params = {};
            params.data= {
                'module': 'ColorizerApp',
                'view':'RelatedModulelist',
                'parent':'Settings',
                'sourceMod':$(this).val()
            }
            app.request.post(params).then(
                function (err, data) {
                    if(data) {
                        $("select[name='relatedmodule']")
                            .find('option')
                            .remove()
                            .end()
                            .append('<option value="">Select an Option</option>');
                        var selectedrelatedmodule = $("input[name='selectedrelatedmodule']").val();
                        jQuery.each( data.relatedlist , function( key, value ) {
                            var selected = '';
                            if(selectedrelatedmodule == value){
                                selected = 'selected = "selected"';
                            }
                            $("select[name='relatedmodule']").append('<option value="'+key+'" '+selected+'>'+value+'</option>');
                                vtUtils.applyFieldElementsView(jQuery('#EditView'));

                            if(selectedrelatedmodule == value){
                                $( "select[name='relatedmodule']" ).change();
                            }
                        });
                        app.helper.hideProgress();
                    }
                },
                function(error) {
                    app.helper.hideProgress();
                }
            );
        });
    },
    loadConditionBlock:function(){
        jQuery("select[name='moduleslist']").change(function (e) {
            var thisInstance = this;
            var recordid = jQuery("input[name='record']").val();
            app.helper.showProgress();
            var params = {};
            var params = {
            'module': 'ColorizerApp',
            'parent': 'Settings',
            'view': 'getWorkflowConditions',
            'record': recordid,
            'module_name': $(this).val()
         }
            app.request.get({data: params}).then(function (error, data) {
                app.helper.hideProgress();
                jQuery('#conditionBlock').html(data);
                vtUtils.applyFieldElementsView(jQuery('#conditionBlock'));
             });
        });  
    },
     /*
     * Function to register the click event for next button
     */
    registerFormSubmitEvent : function() {
        var self = this;
        var form = jQuery('#EditView');
        var params = {
            submitHandler: function(form) {
                var form = jQuery(form);
                self.calculateValues();
                window.onbeforeunload = null;
                jQuery(form).find('button.saveButton').attr('disabled', 'disabled');
                
                self.checkExpressionValidation(form);
                //form.get(0).submit();
                return false;
            }
        };
        form.vtValidate(params);
    },
    /**
     * Function/Handler  which will triggered when user clicks on add condition
     */
    addConditionHandler : function(e) {
        var element = jQuery(e.currentTarget);
        var conditionGroup = element.closest('div.allConditionContainer');
        this.addNewCondition(conditionGroup);
    },
    /**
     * Function/Handler  which will triggered when user clicks on add condition
     */
    addConditionHandlerAny : function(e) {
        var element = jQuery(e.currentTarget);
        var conditionGroup = element.closest('div.anyConditionContainer');
        this.addNewConditionAny(conditionGroup);
    },
    addNewCondition : function(conditionGroupElement){
        var basicElement = jQuery('.conBasic',conditionGroupElement);
        var newRowElement = basicElement.find('.conditionRow').clone(true,true);
        var conditionList = jQuery('.conditionList', conditionGroupElement);
        newRowElement.addClass('op0');
        newRowElement.appendTo(conditionList);
        setTimeout(function(){
            newRowElement.addClass('fadeInx');
        },100)
        //change in to chosen elements
        vtUtils.showSelect2ElementView(newRowElement.find('select.select2'));
        
        return this;
    },
    addNewConditionAny : function(conditionGroupElement){
        var basicElement = jQuery('.conAnyBasic',conditionGroupElement);
        
        var newRowElement = basicElement.find('.conditionRowAny').clone(true,true);
        var conditionList = jQuery('.conditionList', conditionGroupElement);
        newRowElement.addClass('op0');
        newRowElement.appendTo(conditionList);
        setTimeout(function(){
            newRowElement.addClass('fadeInx');
        },100)
        //change in to chosen elements
        vtUtils.showSelect2ElementView(newRowElement.find('select.select2'));
        
        return this;
    },
    /**
     * Event handler which is invoked on add condition
     */
    registerAddCondition : function() {
        var thisInstance = this;
        var divBlockinc;
        jQuery('.addConditionAll button').live('click',function(e){
            thisInstance.addConditionHandler(e);
        });
    },
    /**
     * Event handler which is invoked on add condition
     */
    registerAddConditionAny : function() {
        var thisInstance = this;
        var divBlockinc;
        jQuery('.addConditionAny button').live('click',function(e){
            thisInstance.addConditionHandlerAny(e);
        });
    },
    /**
     * Function to regisgter delete condition event
     */
    registerDeleteCondition : function() {
        var thisInstance = this;
        jQuery('.deleteCondition').live('click', function(e){
            thisInstance.deleteConditionHandler(e);
        });
    },
    /**
     * Function to regisgter delete condition event
     */
    registerDeleteConditionAny : function() {
        var thisInstance = this;
        jQuery('.deleteConditionAny').live('click', function(e){
            thisInstance.deleteConditionHandlerAny(e);
        });
    },
    /**
     * Event handle which will be triggred on deletion of a condition row
     */
    deleteConditionHandler : function(e) {
        var element = jQuery(e.currentTarget);
        var row = element.closest('.conditionRow');
        row.remove();
    },
     /**
     * Event handle which will be triggred on deletion of a condition row
     */
    deleteConditionHandlerAny : function(e) {
        var element = jQuery(e.currentTarget);
        var row = element.closest('.conditionRowAny');
        row.remove();
    },
    registerEvents : function() {
        var thisInstance = this;
        thisInstance.registerAddCondition();
        thisInstance.registerAddConditionAny();
        /*thisInstance.changeSourceModule();*/
        thisInstance.loadConditionBlock();
        thisInstance.registerDeleteCondition();
        thisInstance.registerDeleteConditionAny();
    }
});

jQuery(document).ready(function() {
    var instance = new ColorizerApp_Edit_Js();
    instance.registerEvents();
    Vtiger_Index_Js.getInstance().registerEvents();

    if($("input[name='record']").val() > 0){
        $( "select[name='moduleslist']" ).change();
    }
});