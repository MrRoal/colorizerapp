/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is: vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/

Settings_Vtiger_Index_Js("Settings_ColorizerApp_Index_Js", {
	triggerCreate : function(url) {
		alert('');return false;
        window.location.href = url;
    }
}, {
	addWidget:function(){
	   var thisInstance=this;
	   jQuery('.addWidget').click(function (e) {
	   	   var url = "index.php?module=ColorizerApp&parent=Settings&view=Widget";
	       app.helper.showProgress();
	       popupShown = true;
	       app.request.get({'url':url}).then(function(err,resp) {
	           app.helper.hideProgress();
	           if(err === null) {
	               app.helper.showModal(resp, {'cb' : function(modal) {
	                   popupShown = false;
	               }});

	               var form = jQuery('.form-modalAddWidget');
	               form.on("click","button[name='saveButton']",function(e){
	                   e.preventDefault();
	                   var type = form.find('[name="type"]').val();
	                   thisInstance.createStep2(type);
	               });
	           }
	       });

	   });
	},
	deleteRecord : function() {
        jQuery('.listview-table #deleteColorizer').click(function (e) {
        	var recordid = jQuery(e.currentTarget).data('recordid');
        	
	   	   var url = "index.php?module=ColorizerApp&parent=Settings&action=Delete&recordid="+recordid;
	       app.helper.showProgress();
	       app.request.post({'url':url}).then(function(err,resp) {
	       	   app.helper.hideProgress();
	       	   window.location.href = "index.php?module=ColorizerApp&parent=Settings&view=Config&block=4&fieldid=41";
	       });

	   });
    },
	// to Registering required Events on list view page load
	registerEvents: function () {
		var thisInstance = this;
		thisInstance.addWidget();
		thisInstance.deleteRecord();
	}
});

jQuery(document).ready(function (e) {
		var instance = new Settings_ColorizerApp_Index_Js();
	instance.registerEvents();
});

